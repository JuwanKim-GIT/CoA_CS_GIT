﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using QCS.Analysis;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using Microsoft.Data.Sqlite;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

// WPF와 Windows Forms 클래스 이름 충돌 방지
using UserControl = System.Windows.Controls.UserControl;
using OpenFileDialog = Microsoft.Win32.OpenFileDialog;


namespace QCS
{
    public partial class MsdsRegistrationView : UserControl
    {
        private sealed class PdfItem
        {
            public int Index { get; set; }
            public string FileName { get; set; } = "";
            public string FileSize
            {
                get
                {
                    if (!File.Exists(FullPath)) return "";
                    long bytes = new FileInfo(FullPath).Length;
                    return bytes >= 1048576 ? $"{bytes / 1048576.0:F1} MB" : $"{bytes / 1024.0:F0} KB";
                }
            }
            public string FullPath { get; set; } = "";
            public string Status { get; set; } = "대기";
            public MsdsAnalysisResult? Parsed { get; set; }
        }

        private readonly ObservableCollection<PdfItem> _files = new();
        private readonly MsdsPdfTextExtractor _textExtractor = new();
        private readonly MsdsLocalFieldParser _fieldParser = new();
        private bool _isAnalyzing;

        public MsdsRegistrationView()
        {
            InitializeComponent();
            FilesGrid.ItemsSource = _files;
            UpdateCount();
            SizeChanged += (_, _) => UpdateResponsiveLayout();
            Loaded += (_, _) => UpdateResponsiveLayout();
        }

        // null: 화면 너비에 따른 자동 상태, true/false: 사용자가 선택한 상태
        private bool? _filesOverride;
        private bool? _previewOverride;

        private void ToggleFiles_Click(object sender, RoutedEventArgs e)
        {
            _filesOverride = FilesPanel.Visibility != Visibility.Visible;
            UpdateResponsiveLayout();
        }

        private void TogglePreview_Click(object sender, RoutedEventArgs e)
        {
            _previewOverride = PreviewPanel.Visibility != Visibility.Visible;
            UpdateResponsiveLayout();
        }

        private bool _logExpanded = true;
        private bool _layoutUpdating;
        private int _lastLayoutMode = -1;
        private bool _lastFilesVisible;
        private bool _lastPreviewVisible;

        private void ToggleLog_Click(object sender, RoutedEventArgs e)
        {
            _logExpanded = !_logExpanded;
            LogRow.Height = new GridLength(_logExpanded ? 135 : 0);
            LogList.Visibility = _logExpanded ? Visibility.Visible : Visibility.Collapsed;
            ToggleLogButton.Content = _logExpanded ? "로그 접기 ▲" : "로그 펼치기 ▼";
        }

        private void UpdateResponsiveLayout()
        {
            if (_layoutUpdating || WorkspaceGrid == null || FilesPanel == null ||
                FilesRail == null || PreviewPanel == null) return;

            // ActualWidth는 레이아웃 결과에 따라 달라질 수 있으므로
            // 최상위 컨테이너의 가용 폭을 기준으로 모드를 결정한다.
            double width = ActualWidth - 16;
            if (width <= 0) return;
            int mode = width >= 1450 ? 2 : width >= 900 ? 1 : 0;
            bool showFiles = _filesOverride ?? mode == 2;
            bool showPreview = _previewOverride ?? mode >= 1;
            if (showFiles && width < 1250 && _previewOverride != true)
                showPreview = false;

            // 창 크기 변경 이벤트 중 반복해서 Star/Pixel 폭을 덮어쓰지 않는다.
            // 패널 표시 상태 또는 화면 구간이 바뀔 때만 재배치한다.
            if (_lastLayoutMode == mode && _lastFilesVisible == showFiles &&
                _lastPreviewVisible == showPreview) return;

            _layoutUpdating = true;
            try
            {
                _lastLayoutMode = mode;
                _lastFilesVisible = showFiles;
                _lastPreviewVisible = showPreview;
                FilesPanel.Visibility = showFiles ? Visibility.Visible : Visibility.Collapsed;
                FilesRail.Visibility = showFiles ? Visibility.Collapsed : Visibility.Visible;
                LeftSplitter.Visibility = showFiles ? Visibility.Visible : Visibility.Collapsed;
                PreviewPanel.Visibility = showPreview ? Visibility.Visible : Visibility.Collapsed;
                RightSplitter.Visibility = showPreview ? Visibility.Visible : Visibility.Collapsed;

                var columns = WorkspaceGrid.ColumnDefinitions;
                // PDF 등록 영역은 고정 상한 폭을 사용하여 최대화 시 화면을 독점하지 않는다.
                columns[0].Width = new GridLength(showFiles ? (mode == 2 ? 340 : 300) : 44);
                columns[1].Width = new GridLength(showFiles ? 6 : 5);
                columns[3].Width = new GridLength(showPreview ? 6 : 0);
                columns[2].Width = new GridLength(1, GridUnitType.Star);
                columns[4].Width = showPreview
                    ? new GridLength(mode == 2 ? 480 : 420)
                    : new GridLength(0);

                ToggleFilesButton.Content = showFiles ? "◀  PDF 등록 접기" : "☰  PDF 등록";
                TogglePreviewButton.Content = showPreview ? "▣  원문 접기" : "▣  원문 보기";
            }
            finally { _layoutUpdating = false; }
        }

        private void AddFiles_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Title = "MSDS PDF 파일 선택",
                Filter = "PDF 파일 (*.pdf)|*.pdf",
                Multiselect = true
            };
            if (dialog.ShowDialog() == true) AddPaths(dialog.FileNames);
        }

        private void AddFolder_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFolderDialog { Title = "MSDS PDF 폴더 선택" };
            if (dialog.ShowDialog() != true) return;
            try { AddPaths(Directory.EnumerateFiles(dialog.FolderName, "*", SearchOption.TopDirectoryOnly)
                .Where(p => string.Equals(Path.GetExtension(p), ".pdf", StringComparison.OrdinalIgnoreCase))); }
            catch (Exception ex) { System.Windows.MessageBox.Show(ex.Message, "폴더 읽기 오류"); }
        }

        private void AddPaths(System.Collections.Generic.IEnumerable<string> paths)
        {
            int added = 0;
            foreach (var path in paths)
            {
                if (!File.Exists(path) || _files.Any(x => string.Equals(x.FullPath, path, StringComparison.OrdinalIgnoreCase))) continue;
                _files.Add(new PdfItem { Index = _files.Count + 1, FileName = Path.GetFileName(path), FullPath = path });
                added++;
            }
            LogList.Items.Insert(0, $"{DateTime.Now:HH:mm:ss}  PDF {added}건 추가");
            UpdateCount();
            if (FilesGrid.SelectedItem == null && _files.Count > 0) FilesGrid.SelectedIndex = 0;
        }

        private async void FilesGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (FilesGrid.SelectedItem is not PdfItem item) return;
            FileNameBox.Text = item.FileName;
            ShowExtractedFields(item);
            try
            {
                // WebView2는 비동기로 초기화된다. 초기화 완료 후 선택된 PDF를 연다.
                await PdfBrowser.EnsureCoreWebView2Async();
                // 초기화 도중 사용자가 다른 파일을 선택하거나 목록을 비울 수 있다.
                if (!ReferenceEquals(FilesGrid.SelectedItem, item)) return;
                PdfBrowser.CoreWebView2.Navigate(new Uri(Path.GetFullPath(item.FullPath)).AbsoluteUri);
            }
            catch (Exception ex)
            {
                LogList.Items.Insert(0, $"{DateTime.Now:HH:mm:ss}  미리보기 실패: {ex.Message}");
            }
        }

        private void RemoveSelected_Click(object sender, RoutedEventArgs e)
        {
            if (FilesGrid.SelectedItem is PdfItem item) _files.Remove(item);
            for (int i = 0; i < _files.Count; i++) _files[i].Index = i + 1;
            FilesGrid.Items.Refresh();
            UpdateCount();
            if (_files.Count == 0) ResetPreview();
            else if (FilesGrid.SelectedItem is PdfItem selected) ShowExtractedFields(selected);
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            _files.Clear();
            UpdateCount();
            ResetPreview();
            LogList.Items.Insert(0, $"{DateTime.Now:HH:mm:ss}  목록 초기화");
        }

        private void ResetPreview()
        {
            FileNameBox.Clear();
            ProductNameBox.Clear();
            SupplierNameBox.Clear();
            IngredientsGrid.ItemsSource = null;
            ClearAdditionalFields();
            if (PdfBrowser.CoreWebView2 != null)
                PdfBrowser.CoreWebView2.Navigate("about:blank");
        }

        private static string GetMsdsAnalysisRule()
        {
            using var conn = new SqliteConnection(DatabaseManager.ActiveConnectionString);
            conn.Open();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"SELECT zx_code_cmmt
                                FROM zx_code_mstr
                                WHERE zx_code_fldname = @fieldName
                                  AND COALESCE(zx_code_value, '') = ''";
            cmd.Parameters.AddWithValue("@fieldName", "MSDS_Analysis_rule");
            using var reader = cmd.ExecuteReader();
            if (!reader.Read())
                throw new InvalidOperationException("MSDS_Analysis_rule 설정 레코드가 없습니다.");
            string rule = reader.IsDBNull(0) ? "" : reader.GetValue(0).ToString()?.Trim() ?? "";
            if (reader.Read())
                throw new InvalidOperationException("MSDS_Analysis_rule 설정 레코드가 중복되었습니다.");
            if (rule != "1" && rule != "2" && rule != "3")
                throw new InvalidOperationException($"Comment 값이 올바르지 않습니다: '{rule}' (1, 2, 3만 허용)");
            return rule;
        }

        // 공통코드의 Comment 컬럼에서 AI 설정값을 조회한다.
        private static string GetAiSetting(string fieldName, bool required = true)
        {
            using var conn = new SqliteConnection(DatabaseManager.ActiveConnectionString);
            conn.Open();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"SELECT zx_code_cmmt FROM zx_code_mstr
                                WHERE zx_code_fldname = @fieldName
                                  AND COALESCE(zx_code_value, '') = ''";
            cmd.Parameters.AddWithValue("@fieldName", fieldName);
            using var reader = cmd.ExecuteReader();
            if (!reader.Read())
            {
                if (!required) return "";
                throw new InvalidOperationException(fieldName + " 설정 레코드가 없습니다.");
            }
            string value = reader.IsDBNull(0) ? "" : reader.GetValue(0).ToString()?.Trim() ?? "";
            if (reader.Read()) throw new InvalidOperationException(fieldName + " 설정이 중복되었습니다.");
            if (required && string.IsNullOrWhiteSpace(value))
                throw new InvalidOperationException(fieldName + "의 Comment 값이 비어 있습니다.");
            return value;
        }

        // 등록된 PDF 전체에 대해 로컬 텍스트 추출 테스트를 실행한다.
        // 이 단계에서는 AI 분석, 필드 추출, DB 저장을 수행하지 않는다.
        private async void StartAnalysis_Click(object sender, RoutedEventArgs e)
        {
            if (_isAnalyzing || _files.Count == 0) return;
            // DB 설정에 따라 분석 모듈을 선택한다.
            string analysisRule;
            try { analysisRule = GetMsdsAnalysisRule(); }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show("MSDS 분석 설정 조회 오류: " + ex.Message, "분석 중단");
                return;
            }

            // 1: AI Only - PDF 원본을 AI에 전달하고 기존 검토 화면에 표시한다.
            if (analysisRule == "1")
            {
                string apiKey, model;
                try
                {
                    apiKey = GetAiSetting("MSDS_API_KEY");
                    model = GetAiSetting("MSDS_AI_Model", required: false);
                    if (string.IsNullOrWhiteSpace(model)) model = "gpt-4.1-mini";
                }
                catch (Exception ex)
                {
                    System.Windows.MessageBox.Show("AI 설정 조회 오류: " + ex.Message, "분석 중단");
                    return;
                }

                _isAnalyzing = true;
                StartAnalysisButton.IsEnabled = false;
                var aiTargets = _files.ToArray();
                int aiProcessed = 0;
                AnalysisProgressBar.Value = 0;
                AnalysisProgressText.Text = $"0 / {aiTargets.Length} (0%)";
                LogList.Items.Insert(0, $"{DateTime.Now:HH:mm:ss}  AI PDF 분석 시작 ({aiTargets.Length}건, {model})");
                try
                {
                    var analyzer = new MsdsAiPdfAnalyzer(apiKey, model);
                    foreach (var item in aiTargets)
                    {
                        item.Status = "분석 중";
                        FilesGrid.Items.Refresh();
                        try
                        {
                            var aiResult = await analyzer.AnalyzeAsync(item.FullPath);
                            MsdsAiResultFiles.Save(item.FullPath, aiResult);
                            item.Parsed = aiResult;
                            item.Status = "확인 필요";
                            if (ReferenceEquals(FilesGrid.SelectedItem, item)) ShowExtractedFields(item);
                            LogList.Items.Insert(0, $"{DateTime.Now:HH:mm:ss}  {item.FileName}: AI 추출 {aiResult.Fields.Count}필드, 성분 {aiResult.Ingredients.Count}건 (검증 필요)");
                        }
                        catch (Exception ex)
                        {
                            item.Status = "분석 오류";
                            LogList.Items.Insert(0, $"{DateTime.Now:HH:mm:ss}  {item.FileName}: AI 분석 오류 - {ex.Message}");
                        }
                        aiProcessed++;
                        int percent = (int)Math.Round(aiProcessed * 100.0 / aiTargets.Length);
                        AnalysisProgressBar.Value = percent;
                        AnalysisProgressText.Text = $"{aiProcessed} / {aiTargets.Length} ({percent}%)";
                        FilesGrid.Items.Refresh();
                    }
                    LogList.Items.Insert(0, $"{DateTime.Now:HH:mm:ss}  AI PDF 분석 종료");
                }
                finally
                {
                    _isAnalyzing = false;
                    UpdateCount();
                }
                return;
            }

            // 3: C# + AI는 연결 테스트 이후 구현한다.
            if (analysisRule == "3")
            {
                System.Windows.MessageBox.Show("C# + AI 통합 분석은 다음 단계에서 연결합니다.", "AI 모듈 연결 대기");
                return;
            }

            // 2: 기존 C# 분석 경로를 변경하지 않는다.
            // JSON 오류 시 기존 분석 결과를 변경하지 않는다.
            MsdsRuleSet rules;
            try { rules = MsdsRuleLoader.Load(); }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show("파싱 규칙 오류: " + ex.Message, "JSON 규칙 확인");
                return;
            }
            _isAnalyzing = true;
            StartAnalysisButton.IsEnabled = false;
            var targets = _files.ToArray();
            int processed = 0;
            AnalysisProgressBar.Value = 0;
            AnalysisProgressText.Text = $"0 / {targets.Length} (0%)";
            LogList.Items.Insert(0, $"{DateTime.Now:HH:mm:ss}  PDF 텍스트 추출 시작 ({targets.Length}건)");
            try
            {
                foreach (var item in targets)
                {
                    item.Status = "분석 중";
                    FilesGrid.Items.Refresh();
                    try
                    {
                        var result = await _textExtractor.ExtractAsync(item.FullPath);
                        var parsed = _fieldParser.Parse(result, rules);
                        MsdsTempFiles.Save(item.FullPath, result, parsed);
                        item.Parsed = parsed;
                        item.Status = result.HasExtractableText ? "확인 필요" : "수동 입력";
                        if (ReferenceEquals(FilesGrid.SelectedItem, item)) ShowExtractedFields(item);
                        if (result.HasExtractableText)
                            LogList.Items.Insert(0, $"{DateTime.Now:HH:mm:ss}  {item.FileName}: 후보 필드 {item.Parsed.Fields.Count(f => f.Value != null)}건, CAS {item.Parsed.Ingredients.Count}건 (원문 확인 필요)");
                        string detail = result.HasExtractableText
                            ? $"{result.PageCount}페이지, 텍스트 {result.FullText.Length:N0}자"
                            : $"{result.PageCount}페이지, 텍스트 없음 (수동 입력 대상)";
                        LogList.Items.Insert(0, $"{DateTime.Now:HH:mm:ss}  {item.FileName}: {detail}");
                    }
                    catch (Exception ex)
                    {
                        item.Status = "추출 오류";
                        LogList.Items.Insert(0, $"{DateTime.Now:HH:mm:ss}  {item.FileName}: 오류 - {ex.Message}");
                    }
                    processed++;
                    int percent = (int)Math.Round(processed * 100.0 / targets.Length);
                    AnalysisProgressBar.Value = percent;
                    AnalysisProgressText.Text = $"{processed} / {targets.Length} ({percent}%)";
                    FilesGrid.Items.Refresh();
                }
                LogList.Items.Insert(0, $"{DateTime.Now:HH:mm:ss}  PDF 텍스트 추출 종료");
            }
            finally
            {
                _isAnalyzing = false;
                UpdateCount();
            }
        }

        // 파일별 추출 결과를 표시한다. DB 저장이나 자동 검증은 수행하지 않는다.
        private void ClearAdditionalFields()
        {
            foreach (var box in new[] { GracoCodeBox, RevisionDateBox, RevisionNumberBox,
                PhoneBox, AddressBox, UnNumberBox, HazardCodesBox, AutoIgnitionBox,
                VaporPressureBox, LelBox, UelBox, FlashPointBox }) box.Clear();
        }

        private void ShowExtractedFields(PdfItem item)
        {
            string Get(string key) => item.Parsed?.Fields.FirstOrDefault(f => f.FieldKey == key)?.Value ?? "";
            ProductNameBox.Text = Get("msds_product_name");
            SupplierNameBox.Text = Get("msds_supplier_name");
            GracoCodeBox.Text = Get("msds_sds_code"); // SDS code는 Graco Code 후보: 사용자 검증 필요
            RevisionDateBox.Text = Get("msds_revision_date");
            RevisionNumberBox.Text = Get("msds_revision_number");
            PhoneBox.Text = Get("msds_supplier_phone");
            AddressBox.Text = Get("msds_supplier_address");
            UnNumberBox.Text = Get("msds_un_number");
            HazardCodesBox.Text = Get("msds_hazard_codes");
            AutoIgnitionBox.Text = Get("msds_autoignition");
            VaporPressureBox.Text = Get("msds_vapor_pressure");
            LelBox.Text = Get("msds_lel");
            UelBox.Text = Get("msds_uel");
            FlashPointBox.Text = Get("msds_flash_point");
            IngredientsGrid.ItemsSource = item.Parsed?.Ingredients.Select((v, i) => new
            {
                Index = i + 1, v.Name, v.CasNumber, v.ConcentrationRaw
            }).ToList();
        }

        private void UpdateCount()
        {
            FileCountText.Text = $"등록된 파일 {_files.Count}건";
            StartAnalysisButton.IsEnabled = _files.Count > 0 && !_isAnalyzing;
        }
    }
}
