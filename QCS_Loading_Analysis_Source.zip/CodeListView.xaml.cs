﻿using Microsoft.Data.Sqlite;
using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;

using ComboBox = System.Windows.Controls.ComboBox;

using DataFormats = System.Windows.DataFormats;

// 🎯 [WPF 전용 매싱 완벽 잠금] 누락된 핵심 3가지 별칭 추가로 에러 올킬
using UserControl = System.Windows.Controls.UserControl;
using TextBox = System.Windows.Controls.TextBox;
using Button = System.Windows.Controls.Button;
using DataGrid = System.Windows.Controls.DataGrid;
using MessageBox = System.Windows.MessageBox;           // ◀ 추가 (MessageBox 모호성 해결)
using Clipboard = System.Windows.Clipboard;             // ◀ 추가 (Clipboard 모호성 해결)
using Orientation = System.Windows.Controls.Orientation; // ◀ 추가 (Orientation 모호성 해결)

using Excel = NetOffice.ExcelApi;

namespace QCS
{
    public partial class CodeListView : UserControl
    {
        private DataTable _dtSource = new DataTable();
        private DataGrid _dataGrid = new DataGrid();
        private TextBlock _changeStatus;

        private void CommitPendingEdits()
        {
            _dataGrid.CommitEdit(DataGridEditingUnit.Cell, true);
            _dataGrid.CommitEdit(DataGridEditingUnit.Row, true);
        }

        private (int total, int added, int modified, int deleted) GetChangeCounts()
        {
            int added = 0, modified = 0, deleted = 0, total = 0;
            foreach (DataRow row in _dtSource.Rows)
            {
                switch (row.RowState)
                {
                    case DataRowState.Added: added++; total++; break;
                    case DataRowState.Modified: modified++; total++; break;
                    case DataRowState.Deleted: deleted++; break;
                    default: total++; break;
                }
            }
            return (total, added, modified, deleted);
        }

        private void RefreshChangeStatus()
        {
            if (_changeStatus == null) return;
            var c = GetChangeCounts();
            _changeStatus.Text = $"조회: {c.total:N0}건   │   신규: {c.added:N0}건   │   수정: {c.modified:N0}건   │   삭제: {c.deleted:N0}건";
        }

        private void AttachChangeTracking(DataTable table)
        {
            table.RowChanged += (s, e) => Dispatcher.BeginInvoke(new Action(RefreshChangeStatus));
            table.RowDeleted += (s, e) => Dispatcher.BeginInvoke(new Action(RefreshChangeStatus));
            table.TableNewRow += (s, e) => Dispatcher.BeginInvoke(new Action(RefreshChangeStatus));
        }

        /// <summary>
        /// 상위 탭 관리자가 탭 닫기/이동 전에 호출할 수 있는 확인 메서드.
        /// false이면 탭 닫기/이동을 취소해야 한다.
        /// </summary>
        public bool CanDiscardChanges()
        {
            CommitPendingEdits();
            var c = GetChangeCounts();
            if (c.added + c.modified + c.deleted == 0) return true;
            return MessageBox.Show(
                $"저장하지 않은 변경 사항이 있습니다.\n\n신규: {c.added}건 / 수정: {c.modified}건 / 삭제: {c.deleted}건\n\n계속하면 변경 내용이 사라집니다. 계속하시겠습니까?",
                "미저장 데이터 확인", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes;
        }

        public CodeListView()
        {
            InitializeComponent();
            this.Content = CreateCodeListView();
        }

        private UIElement CreateCodeListView()
        {
            DockPanel mainPanel = new DockPanel();

            // 1차 개선: 검색/작업 영역만 재구성. DataGrid 편집 동작은 그대로 유지한다.
            var outerBar = new StackPanel { Margin = new Thickness(10, 10, 10, 5) };
            var searchBar = new WrapPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 7) };
            var actionBar = new WrapPanel { Orientation = Orientation.Horizontal };

            TextBlock lblField = new TextBlock { Text = "Field Name:", VerticalAlignment = VerticalAlignment.Center,
                FontWeight = FontWeights.Bold, Foreground = System.Windows.Media.Brushes.DimGray };
            ComboBox cboField = new ComboBox { Width = 220, Height = 28, IsEditable = true,
                IsTextSearchEnabled = true, Margin = new Thickness(6, 0, 16, 4),
                VerticalContentAlignment = VerticalAlignment.Center };

            TextBlock lblSearch1 = new TextBlock { Text = "검색어 1:", VerticalAlignment = VerticalAlignment.Center,
                FontWeight = FontWeights.Bold, Foreground = System.Windows.Media.Brushes.DimGray };
            TextBox txtSearch1 = new TextBox { Width = 150, Height = 28,
                VerticalContentAlignment = VerticalAlignment.Center, Margin = new Thickness(6, 0, 16, 4) };
            TextBlock lblSearch2 = new TextBlock { Text = "검색어 2:", VerticalAlignment = VerticalAlignment.Center,
                FontWeight = FontWeights.Bold, Foreground = System.Windows.Media.Brushes.DimGray };
            TextBox txtSearch2 = new TextBox { Width = 150, Height = 28,
                VerticalContentAlignment = VerticalAlignment.Center, Margin = new Thickness(6, 0, 16, 4) };

            Button btnSearch = new Button { Content = "검색", Width = 78, Height = 28, Margin = new Thickness(0, 0, 6, 4) };
            Button btnAll = new Button { Content = "전체조회", Width = 86, Height = 28, Margin = new Thickness(0, 0, 6, 4) };
            Button btnDelete = new Button { Content = "선택삭제", Width = 86, Height = 28,
                Margin = new Thickness(0, 0, 12, 4), Background = System.Windows.Media.Brushes.MistyRose };
            Button btnSave = new Button { Content = "저장", Width = 86, Height = 28,
                Margin = new Thickness(0, 0, 8, 4), Background = System.Windows.Media.Brushes.LightBlue, FontWeight = FontWeights.Bold };
            Button btnExport = new Button { Content = "엑셀출력", Width = 86, Height = 28,
                Margin = new Thickness(0, 0, 8, 4), Background = System.Windows.Media.Brushes.LightGreen, FontWeight = FontWeights.Bold };

            searchBar.Children.Add(lblField);
            searchBar.Children.Add(cboField);
            searchBar.Children.Add(lblSearch1);
            searchBar.Children.Add(txtSearch1);
            searchBar.Children.Add(lblSearch2);
            searchBar.Children.Add(txtSearch2);
            searchBar.Children.Add(btnSearch);
            searchBar.Children.Add(btnAll);
            actionBar.Children.Add(btnDelete);
            actionBar.Children.Add(btnSave);
            actionBar.Children.Add(btnExport);
            // 작업 버튼 우측: 현재 조회 및 미저장 변경 건수
            _changeStatus = new TextBlock
            {
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = System.Windows.HorizontalAlignment.Right,
                TextAlignment = TextAlignment.Right,
                FontWeight = FontWeights.SemiBold,
                Foreground = System.Windows.Media.Brushes.DimGray,
                Margin = new Thickness(10, 0, 0, 4)
            };
            var actionRow = new DockPanel { LastChildFill = true };
            DockPanel.SetDock(actionBar, Dock.Left);
            actionRow.Children.Add(actionBar);
            actionRow.Children.Add(_changeStatus);
            outerBar.Children.Add(searchBar);
            outerBar.Children.Add(actionRow);
            DockPanel.SetDock(outerBar, Dock.Top);
            mainPanel.Children.Add(outerBar);

            // 기존 테이블의 그룹 목록을 가져오되, 새 그룹 입력도 가능하도록 편집형 콤보박스를 사용한다.
            Action loadFieldNames = () =>
            {
                string currentText = cboField.Text;
                try
                {
                    using (var conn = new SqliteConnection(DatabaseManager.GetConnectionString("common")))
                    {
                        conn.Open();
                        using (var cmd = new SqliteCommand(
                            "SELECT DISTINCT zx_code_fldname FROM zx_code_mstr WHERE zx_code_fldname IS NOT NULL ORDER BY zx_code_fldname;", conn))
                        using (var reader = cmd.ExecuteReader())
                        {
                            cboField.Items.Clear();
                            while (reader.Read()) cboField.Items.Add(reader.GetString(0));
                        }
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"Field Name 목록 조회 실패: {ex.Message}");
                }
                cboField.Text = currentText;
            };

            _dataGrid = new DataGrid
            {
                Margin = new Thickness(10, 5, 10, 10),
                IsReadOnly = false,
                CanUserAddRows = true,
                CanUserDeleteRows = true,
                AutoGenerateColumns = true,
                GridLinesVisibility = DataGridGridLinesVisibility.All,
                Background = System.Windows.Media.Brushes.White,
                ColumnWidth = new DataGridLength(1, DataGridLengthUnitType.Auto),

                RowHeaderWidth = 22,

                SelectionMode = DataGridSelectionMode.Extended,
                SelectionUnit = DataGridSelectionUnit.CellOrRowHeader,
                ClipboardCopyMode = DataGridClipboardCopyMode.ExcludeHeader
            };

            _dataGrid.AutoGeneratingColumn += (s, e) =>
            {
                string colName = e.PropertyName;
                switch (colName)
                {
                    case "Field Name": e.Column.Width = new DataGridLength(180); break;
                    case "Code Value": e.Column.Width = new DataGridLength(180); break;
                    case "Comment": e.Column.Width = new DataGridLength(340); break;
                    case "Description1": e.Column.Width = new DataGridLength(340); break;
                    case "Description2": e.Column.Width = new DataGridLength(340); break;
                    default: e.Column.Width = DataGridLength.Auto; break;
                }
            };

            _dataGrid.PreviewKeyDown += DataGrid_PreviewKeyDown;
            _dataGrid.CellEditEnding += (s, e) => Dispatcher.BeginInvoke(new Action(RefreshChangeStatus));
            _dataGrid.RowEditEnding += (s, e) => Dispatcher.BeginInvoke(new Action(RefreshChangeStatus));

            mainPanel.Children.Add(_dataGrid);

            // 데이터 조회 로직
            Action ActionSearch = () =>
            {
                string fieldName = cboField.Text.Trim();
                string key1 = txtSearch1.Text.Trim();
                string key2 = txtSearch2.Text.Trim();

                try
                {
                    var newTable = new DataTable();
                    using (var conn = new SqliteConnection(DatabaseManager.GetConnectionString("common")))
                    {
                        conn.Open();
                        StringBuilder sql = new StringBuilder();
                        sql.AppendLine("SELECT ");
                        sql.AppendLine("    zx_code_fldname AS [Field Name], ");
                        sql.AppendLine("    zx_code_value AS [Code Value], ");
                        sql.AppendLine("    zx_code_cmmt  AS [Comment], ");
                        sql.AppendLine("    zx_code_desc1 AS [Description1], ");
                        sql.AppendLine("    zx_code_desc2 AS [Description2], ");
                        sql.AppendLine("    zx_code_char1 AS [Char#1], ");
                        sql.AppendLine("    zx_code_char2 AS [Char#2] ");
                        sql.AppendLine("FROM zx_code_mstr WHERE 1=1");

                        if (!string.IsNullOrEmpty(fieldName))
                            sql.AppendLine("AND zx_code_fldname = @fieldName");

                        if (!string.IsNullOrEmpty(key1))
                        {
                            sql.AppendLine(@"AND (zx_code_fldname LIKE @likeKey1 
                                               OR zx_code_value LIKE @likeKey1 
                                               OR zx_code_cmmt LIKE @likeKey1 
                                               OR zx_code_desc1 LIKE @likeKey1 
                                               OR zx_code_desc2 LIKE @likeKey1)");
                        }

                        if (!string.IsNullOrEmpty(key2))
                        {
                            sql.AppendLine(@"AND (zx_code_fldname LIKE @likeKey2 
                                               OR zx_code_value LIKE @likeKey2 
                                               OR zx_code_cmmt LIKE @likeKey2 
                                               OR zx_code_desc1 LIKE @likeKey2 
                                               OR zx_code_desc2 LIKE @likeKey2)");
                        }

                        using (var cmd = new SqliteCommand(sql.ToString(), conn))
                        {
                            if (!string.IsNullOrEmpty(fieldName)) cmd.Parameters.AddWithValue("@fieldName", fieldName);
                            if (!string.IsNullOrEmpty(key1)) cmd.Parameters.AddWithValue("@likeKey1", $"%{key1}%");
                            if (!string.IsNullOrEmpty(key2)) cmd.Parameters.AddWithValue("@likeKey2", $"%{key2}%");

                            using (var reader = cmd.ExecuteReader())
                            {
                                newTable.Load(reader);
                            }
                        }
                    }

                    _dtSource = newTable;
                    AttachChangeTracking(_dtSource);
                    _dataGrid.ItemsSource = null;
                    _dataGrid.ItemsSource = _dtSource.DefaultView;
                    RefreshChangeStatus();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"데이터 조회 중 에러 발생:\n{ex.Message}", "조회 오류", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            };

            // 데이터 일괄 저장 (CUD 통합 처리) 로직
            Action ActionSave = () =>
            {
                // 셀/행 편집 내용을 먼저 확정
                CommitPendingEdits();

                int updateCount = 0;
                int insertCount = 0;
                int deleteCount = 0;

                try
                {
                    using (var conn = new SqliteConnection(DatabaseManager.GetConnectionString("common")))
                    {
                        conn.Open();
                        using (var tx = conn.BeginTransaction())
                        {
                            foreach (DataRow row in _dtSource.Rows)
                            {
                                if (row.RowState == DataRowState.Deleted)
                                {
                                    string deleteQuery = "DELETE FROM zx_code_mstr WHERE zx_code_fldname = @FieldName AND COALESCE(zx_code_value, '') = @CodeValue;";
                                    using (var cmd = new SqliteCommand(deleteQuery, conn, tx))
                                    {
                                        cmd.Parameters.AddWithValue("@FieldName", row["Field Name", DataRowVersion.Original]);
                                        cmd.Parameters.AddWithValue("@CodeValue", row["Code Value", DataRowVersion.Original] == DBNull.Value ? "" : row["Code Value", DataRowVersion.Original]);
                                        int affectedRows = cmd.ExecuteNonQuery();
                                        if (affectedRows != 1)
                                            throw new InvalidOperationException($"코드 삭제 대상이 정확히 1건이 아닙니다. 대상: {affectedRows}건");
                                        deleteCount += affectedRows;
                                    }
                                }
                                else if (row.RowState == DataRowState.Modified)
                                {
                                    string updateQuery = @"
                                        UPDATE zx_code_mstr 
                                        SET zx_code_cmmt = @Comment,
                                            zx_code_desc1 = @Desc1,
                                            zx_code_desc2 = @Desc2,
                                            zx_code_char1 = @Char1,
                                            zx_code_char2 = @Char2
                                        WHERE zx_code_fldname = @FieldName AND COALESCE(zx_code_value, '') = @CodeValue;";

                                    using (var cmd = new SqliteCommand(updateQuery, conn, tx))
                                    {
                                        cmd.Parameters.AddWithValue("@Comment", row["Comment"] ?? DBNull.Value);
                                        cmd.Parameters.AddWithValue("@Desc1", row["Description1"] ?? DBNull.Value);
                                        cmd.Parameters.AddWithValue("@Desc2", row["Description2"] ?? DBNull.Value);
                                        cmd.Parameters.AddWithValue("@Char1", row["Char#1"] ?? DBNull.Value);
                                        cmd.Parameters.AddWithValue("@Char2", row["Char#2"] ?? DBNull.Value);
                                        cmd.Parameters.AddWithValue("@FieldName", row["Field Name", DataRowVersion.Original]);
                                        cmd.Parameters.AddWithValue("@CodeValue", row["Code Value", DataRowVersion.Original] == DBNull.Value ? "" : row["Code Value", DataRowVersion.Original]);
                                        int affectedRows = cmd.ExecuteNonQuery();
                                        if (affectedRows != 1)
                                            throw new InvalidOperationException($"코드 수정 대상이 정확히 1건이 아닙니다. 대상: {affectedRows}건, Field Name: {row["Field Name"]}, Code Value: {row["Code Value"]}");
                                        updateCount += affectedRows;
                                    }
                                }
                                else if (row.RowState == DataRowState.Added)
                                {
                                    if (row["Field Name"] == DBNull.Value || string.IsNullOrEmpty(row["Field Name"].ToString())) continue;

                                    string insertQuery = @"
                                        INSERT INTO zx_code_mstr (zx_code_fldname, zx_code_value, zx_code_cmmt, zx_code_desc1, zx_code_desc2, zx_code_char1, zx_code_char2)
                                        VALUES (@FieldName, @CodeValue, @Comment, @Desc1, @Desc2, @Char1, @Char2);";

                                    using (var cmd = new SqliteCommand(insertQuery, conn, tx))
                                    {
                                        cmd.Parameters.AddWithValue("@FieldName", row["Field Name"]);
                                        cmd.Parameters.AddWithValue("@CodeValue", row["Code Value"] ?? "");
                                        cmd.Parameters.AddWithValue("@Comment", row["Comment"] ?? DBNull.Value);
                                        cmd.Parameters.AddWithValue("@Desc1", row["Description1"] ?? DBNull.Value);
                                        cmd.Parameters.AddWithValue("@Desc2", row["Description2"] ?? DBNull.Value);
                                        cmd.Parameters.AddWithValue("@Char1", row["Char#1"] ?? DBNull.Value);
                                        cmd.Parameters.AddWithValue("@Char2", row["Char#2"] ?? DBNull.Value);
                                        cmd.ExecuteNonQuery();
                                    }
                                    insertCount++;
                                }
                            }
                            tx.Commit();
                        }
                    }

                    if (updateCount > 0 || insertCount > 0 || deleteCount > 0)
                    {
                        MessageBox.Show($"DB 저장이 정상 완료되었습니다!\n(수정: {updateCount}건, 추가: {insertCount}건, 삭제: {deleteCount}건)", "저장 완료", MessageBoxButton.OK, MessageBoxImage.Information);
                        loadFieldNames();
                        ActionSearch();
                    }
                    else
                    {
                        MessageBox.Show("변경된 데이터가 없습니다.", "알림", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"데이터 저장 중 오류가 발생했습니다:\n{ex.Message}", "저장 오류", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            };

            btnDelete.Click += (s, e) =>
            {
                if (_dataGrid.SelectedItems.Count == 0)
                {
                    MessageBox.Show("삭제할 행을 그리드에서 선택해 주세요.", "알림", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (MessageBox.Show("선택한 행들을 화면에서 제거하시겠습니까?\n(최종 DB 반영은 '저장' 버튼을 누르셔야 처리됩니다.)", "삭제 확인", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    System.Collections.ArrayList selectedList = new System.Collections.ArrayList(_dataGrid.SelectedItems);
                    foreach (var item in selectedList)
                    {
                        if (item is DataRowView rowView)
                        {
                            rowView.Row.Delete();
                        }
                    }
                }
            };

            // 파일 저장 없이 화면에 바로 엑셀 띄우기 (Export to Direct View)
            btnExport.Click += (s, e) =>
            {
                if (_dtSource == null || _dtSource.Rows.Count == 0)
                {
                    MessageBox.Show("출력할 데이터가 없습니다.", "알림", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                Excel.Application excelApp = null;
                Excel.Workbook wb = null;
                Excel.Worksheet ws = null;

                try
                {
                    excelApp = new Excel.Application();
                    excelApp.Visible = false;
                    excelApp.DisplayAlerts = false;

                    wb = excelApp.Workbooks.Add();
                    ws = (Excel.Worksheet)wb.Sheets[1];
                    ws.Name = "CodeList_View";

                    int colCount = _dtSource.Columns.Count;
                    for (int c = 0; c < colCount; c++)
                    {
                        ((Excel.Range)ws.Cells[1, c + 1]).Value = _dtSource.Columns[c].ColumnName;
                    }

                    int rowCount = _dtSource.Rows.Count;
                    int excelRowIdx = 2;

                    for (int r = 0; r < rowCount; r++)
                    {
                        DataRow row = _dtSource.Rows[r];
                        if (row.RowState == DataRowState.Deleted) continue;

                        for (int c = 0; c < colCount; c++)
                        {
                            ((Excel.Range)ws.Cells[excelRowIdx, c + 1]).Value = row[c]?.ToString() ?? "";
                        }
                        excelRowIdx++;
                    }

                    excelApp.Visible = true;
                    excelApp.DisplayAlerts = true;

                    wb = null;
                    excelApp = null;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"엑셀을 화면에 띄우는 중 오류가 발생했습니다:\n{ex.Message}", "오류", MessageBoxButton.OK, MessageBoxImage.Error);
                    if (wb != null) { wb.Dispose(); wb = null; }
                    if (excelApp != null) { excelApp.Quit(); excelApp.Dispose(); excelApp = null; }
                }
            };

            Action guardedSearch = () =>
            {
                if (CanDiscardChanges()) ActionSearch();
            };
            btnSearch.Click += (s, e) => guardedSearch();
            btnAll.Click += (s, e) =>
            {
                if (!CanDiscardChanges()) return;
                cboField.Text = "";
                txtSearch1.Clear();
                txtSearch2.Clear();
                ActionSearch();
            };
            cboField.KeyDown += (s, e) => { if (e.Key == System.Windows.Input.Key.Enter) guardedSearch(); };
            btnSave.Click += (s, e) => ActionSave();
            txtSearch1.KeyDown += (s, e) => { if (e.Key == System.Windows.Input.Key.Enter) guardedSearch(); };
            txtSearch2.KeyDown += (s, e) => { if (e.Key == System.Windows.Input.Key.Enter) guardedSearch(); };

            loadFieldNames();
            ActionSearch();

            return mainPanel;
        }

        // 🎯 [핵심 기능] 아웃룩/웹메일 표 복사(HTML Format) 및 일반 TSV 복사 완벽 통합 파싱
        private void DataGrid_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.V && (System.Windows.Input.Keyboard.Modifiers & System.Windows.Input.ModifierKeys.Control) == System.Windows.Input.ModifierKeys.Control)
            {
                e.Handled = true; // WPF 기본 붙여넣기 차단

                List<List<string>> parsedTable = null;

                // 1. 아웃룩/웹메일 HTML 표 데이터 우선 처리 (HTML 포맷이 존재하는 경우)
                if (Clipboard.ContainsData(DataFormats.Html))
                {
                    string htmlText = Clipboard.GetData(DataFormats.Html) as string;
                    if (!string.IsNullOrEmpty(htmlText))
                    {
                        parsedTable = ParseHtmlTable(htmlText);
                    }
                }

                // 2. HTML 표 데이터가 없거나 실패 시 텍스트 파싱으로 Fallback
                if (parsedTable == null || parsedTable.Count == 0)
                {
                    string clipboardText = Clipboard.GetText();
                    if (string.IsNullOrWhiteSpace(clipboardText)) return;
                    parsedTable = ParseTsvWithQuotes(clipboardText);
                }

                if (parsedTable == null || parsedTable.Count == 0) return;

                // 3. 현재 선택된 행/열 위치 추적
                int startRowIndex = _dataGrid.SelectedIndex;
                if (startRowIndex < 0 && _dataGrid.CurrentItem != null)
                {
                    startRowIndex = _dataGrid.Items.IndexOf(_dataGrid.CurrentItem);
                }
                if (startRowIndex < 0) startRowIndex = _dtSource.Rows.Count;

                int startColumnIndex = 0;
                if (_dataGrid.CurrentCell != null && _dataGrid.CurrentCell.Column != null)
                {
                    startColumnIndex = _dataGrid.CurrentCell.Column.DisplayIndex;
                }

                // 4. 추적된 셀 위치부터 데이터 매핑
                for (int i = 0; i < parsedTable.Count; i++)
                {
                    List<string> rowCells = parsedTable[i];
                    int targetRowIndex = startRowIndex + i;

                    DataRow targetRow = null;

                    if (targetRowIndex < _dtSource.Rows.Count)
                    {
                        targetRow = _dtSource.Rows[targetRowIndex];
                        if (targetRow.RowState == DataRowState.Deleted) continue;
                    }
                    else
                    {
                        targetRow = _dtSource.NewRow();
                        _dtSource.Rows.Add(targetRow);
                    }

                    for (int j = 0; j < rowCells.Count; j++)
                    {
                        int targetColumnIndex = startColumnIndex + j;

                        if (targetColumnIndex < _dtSource.Columns.Count)
                        {
                            string colName = _dtSource.Columns[targetColumnIndex].ColumnName;
                            targetRow[colName] = rowCells[j];
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 🎯 메일/웹 HTML 표 구조(tr, td)를 직접 추출하는 파서
        /// </summary>
        private List<List<string>> ParseHtmlTable(string html)
        {
            var table = new List<List<string>>();

            try
            {
                // 간단한 정규식으로 <tr>...</tr> 행 추출
                var trMatches = System.Text.RegularExpressions.Regex.Matches(
                    html, @"<tr[^>]*>(.*?)</tr>", System.Text.RegularExpressions.RegexOptions.Singleline | System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                foreach (System.Text.RegularExpressions.Match trMatch in trMatches)
                {
                    var row = new List<string>();
                    // <td> 또는 <th> 추출
                    var tdMatches = System.Text.RegularExpressions.Regex.Matches(
                        trMatch.Groups[1].Value, @"<t[dh][^>]*>(.*?)</t[dh]>", System.Text.RegularExpressions.RegexOptions.Singleline | System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                    foreach (System.Text.RegularExpressions.Match tdMatch in tdMatches)
                    {
                        string cellHtml = tdMatch.Groups[1].Value;

                        // HTML 태그 제거 및 디코딩 (&nbsp; -> 공백 등)
                        string cellText = System.Text.RegularExpressions.Regex.Replace(cellHtml, @"<[^>]+>", "").Trim();
                        cellText = System.Net.WebUtility.HtmlDecode(cellText);

                        // 연속된 공백 및 줄바꿈 정리
                        cellText = System.Text.RegularExpressions.Regex.Replace(cellText, @"\s+", " ").Trim();
                        row.Add(cellText);
                    }

                    if (row.Count > 0 && row.Exists(s => !string.IsNullOrEmpty(s)))
                    {
                        table.Add(row);
                    }
                }
            }
            catch { }

            return table;
        }

        /// <summary>
        /// 🎯 일반 TSV(텍스트) 파서
        /// </summary>
        private List<List<string>> ParseTsvWithQuotes(string text)
        {
            var result = new List<List<string>>();
            var currentRow = new List<string>();
            var currentCell = new StringBuilder();
            bool inQuotes = false;

            string normalized = text.Replace("\r\n", "\n").Replace("\r", "\n");

            for (int i = 0; i < normalized.Length; i++)
            {
                char c = normalized[i];

                if (c == '"')
                {
                    if (inQuotes && i + 1 < normalized.Length && normalized[i + 1] == '"')
                    {
                        currentCell.Append('"');
                        i++;
                    }
                    else
                    {
                        inQuotes = !inQuotes;
                    }
                }
                else if (c == '\t' && !inQuotes)
                {
                    currentRow.Add(currentCell.ToString().Trim());
                    currentCell.Clear();
                }
                else if (c == '\n' && !inQuotes)
                {
                    currentRow.Add(currentCell.ToString().Trim());
                    currentCell.Clear();

                    if (currentRow.Exists(s => !string.IsNullOrWhiteSpace(s)))
                    {
                        result.Add(currentRow);
                    }
                    currentRow = new List<string>();
                }
                else
                {
                    currentCell.Append(c);
                }
            }

            if (currentCell.Length > 0 || currentRow.Count > 0)
            {
                currentRow.Add(currentCell.ToString().Trim());
                if (currentRow.Exists(s => !string.IsNullOrWhiteSpace(s)))
                {
                    result.Add(currentRow);
                }
            }

            return result;
        }
    }
}