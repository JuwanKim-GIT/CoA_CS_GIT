﻿using Microsoft.Data.Sqlite;
using System;
using System.Data;
using System.Text;
using System.Windows;
using System.Windows.Controls;

using DataFormats = System.Windows.DataFormats;

// 🎯 [WPF 전용 매싱 완벽 잠금] 마지막 남은 에러 3개를 저격하기 위한 최종 별칭 추가
using UserControl = System.Windows.Controls.UserControl;
using DataGrid = System.Windows.Controls.DataGrid;
using TextBox = System.Windows.Controls.TextBox;
using Button = System.Windows.Controls.Button;
using MessageBox = System.Windows.MessageBox;
using Orientation = System.Windows.Controls.Orientation;   // ◀ 추가 (Orientation 에러 해결)
using DataGridCell = System.Windows.Controls.DataGridCell; // ◀ 추가 (DataGridCell 에러 해결)
using Clipboard = System.Windows.Clipboard;               // ◀ 추가 (Clipboard 에러 해결)

using Excel = NetOffice.ExcelApi;

namespace QCS
{
    public partial class TestResultListView : UserControl
    {
        private DataTable _dtSource = new DataTable();
        private DataGrid _dataGrid = new DataGrid();

        public TestResultListView()
        {
            InitializeComponent();
            this.Content = CreateTestResultListView();
        }

        private UIElement CreateTestResultListView()
        {
            DockPanel mainPanel = new DockPanel();

            // 검색/작업 영역: 기존 그리드 및 DB 편집 로직과 독립적으로 구성
            var outerBar = new StackPanel { Margin = new Thickness(10, 10, 10, 5) };
            var searchBar = new WrapPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 7) };
            var actionBar = new DockPanel { LastChildFill = true };
            var actionButtons = new WrapPanel { Orientation = Orientation.Horizontal };
            TextBlock lblSearch1 = new TextBlock { Text = "검색어 1:", VerticalAlignment = VerticalAlignment.Center,
                FontWeight = FontWeights.Bold, Foreground = System.Windows.Media.Brushes.DimGray };
            TextBox txtSearch1 = new TextBox { Width = 150, Height = 28,
                VerticalContentAlignment = VerticalAlignment.Center, Margin = new Thickness(6, 0, 16, 4) };
            TextBlock lblSearch2 = new TextBlock { Text = "검색어 2:", VerticalAlignment = VerticalAlignment.Center,
                FontWeight = FontWeights.Bold, Foreground = System.Windows.Media.Brushes.DimGray };
            TextBox txtSearch2 = new TextBox { Width = 150, Height = 28,
                VerticalContentAlignment = VerticalAlignment.Center, Margin = new Thickness(6, 0, 16, 4) };
            Button btnSearch = new Button { Content = "검색", Width = 78, Height = 28, Margin = new Thickness(0, 0, 6, 4) };
            Button btnAll = new Button { Content = "전체조회", Width = 86, Height = 28, Margin = new Thickness(0, 0, 6, 4) };
            Button btnDelete = new Button { Content = "선택삭제", Width = 86, Height = 28,
                Margin = new Thickness(0, 0, 12, 4), Background = System.Windows.Media.Brushes.MistyRose };
            Button btnSave = new Button { Content = "저장", Width = 86, Height = 28,
                Margin = new Thickness(0, 0, 8, 4), Background = System.Windows.Media.Brushes.LightBlue, FontWeight = FontWeights.Bold };
            Button btnExport = new Button { Content = "엑셀출력", Width = 86, Height = 28,
                Margin = new Thickness(0, 0, 8, 4), Background = System.Windows.Media.Brushes.LightGreen, FontWeight = FontWeights.Bold };
            TextBlock lblStatus = new TextBlock { Text = "조회: 0건  │  신규: 0건  │  수정: 0건  │  삭제: 0건",
                VerticalAlignment = VerticalAlignment.Center, HorizontalAlignment = System.Windows.HorizontalAlignment.Right,
                TextAlignment = TextAlignment.Right, Margin = new Thickness(12, 0, 4, 4),
                Foreground = System.Windows.Media.Brushes.DimGray, FontWeight = FontWeights.SemiBold };

            searchBar.Children.Add(lblSearch1);
            searchBar.Children.Add(txtSearch1);
            searchBar.Children.Add(lblSearch2);
            searchBar.Children.Add(txtSearch2);
            searchBar.Children.Add(btnSearch);
            searchBar.Children.Add(btnAll);
            actionButtons.Children.Add(btnDelete);
            actionButtons.Children.Add(btnSave);
            actionButtons.Children.Add(btnExport);
            DockPanel.SetDock(actionButtons, Dock.Left);
            actionBar.Children.Add(actionButtons);
            actionBar.Children.Add(lblStatus);
            outerBar.Children.Add(searchBar);
            outerBar.Children.Add(actionBar);
            DockPanel.SetDock(outerBar, Dock.Top);
            mainPanel.Children.Add(outerBar);

            _dataGrid = new DataGrid
            {
                Margin = new Thickness(10, 5, 10, 10),
                IsReadOnly = false,
                CanUserAddRows = true,
                CanUserDeleteRows = true,
                AutoGenerateColumns = true,
                GridLinesVisibility = DataGridGridLinesVisibility.All,
                Background = System.Windows.Media.Brushes.White,
                ColumnWidth = new DataGridLength(1, DataGridLengthUnitType.Auto),

                RowHeaderWidth = 22,

                SelectionMode = DataGridSelectionMode.Extended,
                SelectionUnit = DataGridSelectionUnit.CellOrRowHeader,
                ClipboardCopyMode = DataGridClipboardCopyMode.ExcludeHeader
            };

            _dataGrid.AutoGeneratingColumn += (s, e) =>
            {
                string colName = e.PropertyName;

                if (colName == "no")
                {
                    e.Column.Width = new DataGridLength(50);
                }
                else if (colName == "Characteristic")
                {
                    e.Column.Width = new DataGridLength(350);
                }
                else if (colName == "UoM")
                {
                    e.Column.Width = new DataGridLength(60);
                }
                else if (colName == "First Value" || colName == "Last Value" || colName == "Lower Limit" || colName == "Upper Limit")
                {
                    e.Column.Width = new DataGridLength(100);

                    var rightAlignStyle = new Style(typeof(DataGridCell));
                    rightAlignStyle.Setters.Add(new Setter(TextBlock.TextAlignmentProperty, TextAlignment.Right));
                    e.Column.CellStyle = rightAlignStyle;
                }
            };

            // 🎯 [이벤트 연결] 엑셀 대량 붙여넣기 감지기 드디어 장착!
            _dataGrid.PreviewKeyDown += DataGrid_PreviewKeyDown;

            mainPanel.Children.Add(_dataGrid);

            // DataRowState 기반 실시간 건수 표시 (추가/수정/삭제 모두 포함)
            Action updateStatus = () =>
            {
                int added = 0, modified = 0, deleted = 0, visible = 0;
                foreach (DataRow row in _dtSource.Rows)
                {
                    switch (row.RowState)
                    {
                        case DataRowState.Added: added++; visible++; break;
                        case DataRowState.Modified: modified++; visible++; break;
                        case DataRowState.Deleted: deleted++; break;
                        default: visible++; break;
                    }
                }
                lblStatus.Text = $"조회: {visible}건  │  신규: {added}건  │  수정: {modified}건  │  삭제: {deleted}건";
            };
            Action<DataTable> watchTable = table =>
            {
                table.RowChanged += (sender, args) => updateStatus();
                table.RowDeleted += (sender, args) => updateStatus();
                table.TableNewRow += (sender, args) => updateStatus();
                updateStatus();
            };
            Func<bool> confirmDiscard = () =>
            {
                // 셀/행 편집 중인 값도 먼저 DataTable에 반영
                _dataGrid.CommitEdit(DataGridEditingUnit.Cell, true);
                _dataGrid.CommitEdit(DataGridEditingUnit.Row, true);
                int added = 0, modified = 0, deleted = 0;
                foreach (DataRow row in _dtSource.Rows)
                {
                    if (row.RowState == DataRowState.Added) added++;
                    else if (row.RowState == DataRowState.Modified) modified++;
                    else if (row.RowState == DataRowState.Deleted) deleted++;
                }
                if (added + modified + deleted == 0) return true;
                return MessageBox.Show(
                    $"저장하지 않은 변경 사항이 있습니다.\n신규: {added}건 / 수정: {modified}건 / 삭제: {deleted}건\n계속하면 변경 내용이 사라집니다. 계속하시겠습니까?",
                    "미저장 변경 사항", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes;
            };

            bool skipDiscardOnce = false;

            // 데이터 조회 로직 (네트워크 병목 완벽 방어형으로 튜닝 🎯)
            Action ActionSearch = () =>
            {
                if (!skipDiscardOnce && !confirmDiscard()) return;
                skipDiscardOnce = false;
                DataTable loadedTable = new DataTable();
                string key1 = txtSearch1.Text.Trim();
                string key2 = txtSearch2.Text.Trim();

                //// 🔒 [보안 및 성능 자물쇠] 네트워크 마비 방지를 위해 검색어가 둘 다 없으면 전체 조회를 막거나 최신순 제한을 둡니다.
                //if (string.IsNullOrEmpty(key1) && string.IsNullOrEmpty(key2))
                //{
                //    MessageBox.Show("네트워크 속도 안정성을 위해 검색어를 입력하신 후 조회를 진행해 주세요.\n(예: batch no, 품번, 검사항목 등)", "검색어 입력 필요", MessageBoxButton.OK, MessageBoxImage.Warning);
                //    return;
                //}

                try
                {
                    using (var conn = new SqliteConnection(DatabaseManager.GetConnectionString("quality")))
                    {
                        conn.Open();

                        StringBuilder sql = new StringBuilder();
                        sql.AppendLine("SELECT ");
                        sql.AppendLine("    qmir_batch AS [batch no], ");
                        sql.AppendLine("    qmir_no AS [no], ");
                        sql.AppendLine("    qmir_charac AS [Characteristic], ");
                        sql.AppendLine("    printf('%.5f', qmir_first_value) AS [First Value], ");
                        sql.AppendLine("    printf('%.5f', qmir_last_value) AS [Last Value], ");
                        sql.AppendLine("    printf('%.5f', qmir_ltol) AS [Lower Limit], ");
                        sql.AppendLine("    printf('%.5f', qmir_utol) AS [Upper Limit], ");
                        sql.AppendLine("    qmir_uom AS [UoM], ");
                        sql.AppendLine("    qmir_part AS [part], ");
                        sql.AppendLine("    qmir_mf_date AS [mfdate] ");
                        sql.AppendLine("FROM qmir_det WHERE 1=1");

                        if (!string.IsNullOrEmpty(key1))
                        {
                            sql.AppendLine(@"AND (qmir_batch LIKE @likeKey1 
                                               OR qmir_charac LIKE @likeKey1 
                                               OR qmir_part LIKE @likeKey1)");
                        }

                        if (!string.IsNullOrEmpty(key2))
                        {
                            sql.AppendLine(@"AND (qmir_batch LIKE @likeKey2 
                                               OR qmir_charac LIKE @likeKey2 
                                               OR qmir_part LIKE @likeKey2)");
                        }
                        
                        // ⚡ 만약 검색어가 있을 때도 데이터가 너무 많다면 뒤에 
                        // sql.AppendLine(" ORDER BY qmir_reg_date DESC LIMIT 500"); 처럼 제한을 걸 수도 있어!

                        using (var cmd = new SqliteCommand(sql.ToString(), conn))
                        {
                            if (!string.IsNullOrEmpty(key1)) cmd.Parameters.AddWithValue("@likeKey1", $"%{key1}%");
                            if (!string.IsNullOrEmpty(key2)) cmd.Parameters.AddWithValue("@likeKey2", $"%{key2}%");

                            using (var reader = cmd.ExecuteReader())
                            {
                                loadedTable.Load(reader);
                            }
                        }
                    }

                    _dtSource = loadedTable;
                    _dataGrid.ItemsSource = null;
                    _dataGrid.ItemsSource = _dtSource.DefaultView;
                    watchTable(_dtSource);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"데이터 조회 중 에러 발생:\n{ex.Message}", "조회 오류", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            };

            // 데이터 일괄 저장 로직
            Action ActionSave = () =>
            {
                _dataGrid.CommitEdit(DataGridEditingUnit.Cell, true);
                _dataGrid.CommitEdit(DataGridEditingUnit.Row, true);

                int updateCount = 0;
                int insertCount = 0;
                int deleteCount = 0;

                object ToDbDouble(object value)
                {
                    if (value == DBNull.Value || value == null) return DBNull.Value;
                    if (double.TryParse(value.ToString(), out double res)) return res;
                    return DBNull.Value;
                }

                try
                {
                    using (var conn = new SqliteConnection(DatabaseManager.GetConnectionString("quality")))
                    {
                        conn.Open();
                        using (var tx = conn.BeginTransaction())
                        {
                            foreach (DataRow row in _dtSource.Rows)
                            {
                                if (row.RowState == DataRowState.Deleted)
                                {
                                    string deleteQuery = "DELETE FROM qmir_det WHERE qmir_batch = @BatchKey AND qmir_no = @NoKey;";
                                    using (var cmd = new SqliteCommand(deleteQuery, conn, tx))
                                    {
                                        cmd.Parameters.AddWithValue("@BatchKey", row["batch no", DataRowVersion.Original]);
                                        cmd.Parameters.AddWithValue("@NoKey", row["no", DataRowVersion.Original]);
                                        cmd.ExecuteNonQuery();
                                    }
                                    deleteCount++;
                                }
                                else if (row.RowState == DataRowState.Modified)
                                {
                                    string updateQuery = @"
                                        UPDATE qmir_det 
                                        SET qmir_charac = @Charac,
                                            qmir_first_value = @FirstVal,
                                            qmir_last_value = @LastVal,
                                            qmir_ltol = @Ltol,
                                            qmir_utol = @Utol,
                                            qmir_uom = @Uom,
                                            qmir_part = @Part,
                                            qmir_mf_date = @MfDate
                                        WHERE qmir_batch = @BatchKey AND qmir_no = @NoKey;";

                                    using (var cmd = new SqliteCommand(updateQuery, conn, tx))
                                    {
                                        cmd.Parameters.AddWithValue("@Charac", row["Characteristic"] ?? DBNull.Value);
                                        cmd.Parameters.AddWithValue("@FirstVal", ToDbDouble(row["First Value"]));
                                        cmd.Parameters.AddWithValue("@LastVal", ToDbDouble(row["Last Value"]));
                                        cmd.Parameters.AddWithValue("@Ltol", ToDbDouble(row["Lower Limit"]));
                                        cmd.Parameters.AddWithValue("@Utol", ToDbDouble(row["Upper Limit"]));
                                        cmd.Parameters.AddWithValue("@Uom", row["UoM"] ?? DBNull.Value);
                                        cmd.Parameters.AddWithValue("@Part", row["part"] ?? DBNull.Value);
                                        cmd.Parameters.AddWithValue("@MfDate", row["mfdate"] ?? DBNull.Value);

                                        cmd.Parameters.AddWithValue("@BatchKey", row["batch no", DataRowVersion.Original]);
                                        cmd.Parameters.AddWithValue("@NoKey", row["no", DataRowVersion.Original]);
                                        cmd.ExecuteNonQuery();
                                    }
                                    updateCount++;
                                }
                                else if (row.RowState == DataRowState.Added)
                                {
                                    if (row["batch no"] == DBNull.Value || string.IsNullOrEmpty(row["batch no"].ToString())) continue;
                                    if (row["no"] == DBNull.Value || string.IsNullOrEmpty(row["no"].ToString())) continue;

                                    string insertQuery = @"
                                        INSERT INTO qmir_det (
                                            qmir_batch, qmir_no, qmir_charac, qmir_first_value, 
                                            qmir_last_value, qmir_ltol, qmir_utol, qmir_uom, 
                                            qmir_part, qmir_mf_date
                                        ) VALUES (
                                            @Batch, @No, @Charac, @FirstVal, 
                                            @LastVal, @Ltol, @Utol, @Uom, 
                                            @Part, @MfDate
                                        );";

                                    using (var cmd = new SqliteCommand(insertQuery, conn, tx))
                                    {
                                        cmd.Parameters.AddWithValue("@Batch", row["batch no"]);
                                        cmd.Parameters.AddWithValue("@No", row["no"]);
                                        cmd.Parameters.AddWithValue("@Charac", row["Characteristic"] ?? DBNull.Value);
                                        cmd.Parameters.AddWithValue("@FirstVal", ToDbDouble(row["First Value"]));
                                        cmd.Parameters.AddWithValue("@LastVal", ToDbDouble(row["Last Value"]));
                                        cmd.Parameters.AddWithValue("@Ltol", ToDbDouble(row["Lower Limit"]));
                                        cmd.Parameters.AddWithValue("@Utol", ToDbDouble(row["Upper Limit"]));
                                        cmd.Parameters.AddWithValue("@Uom", row["UoM"] ?? DBNull.Value);
                                        cmd.Parameters.AddWithValue("@Part", row["part"] ?? DBNull.Value);
                                        cmd.Parameters.AddWithValue("@MfDate", row["mfdate"] ?? DBNull.Value);
                                        cmd.ExecuteNonQuery();
                                    }
                                    insertCount++;
                                }
                            }
                            tx.Commit();
                        }
                    }

                    if (updateCount > 0 || insertCount > 0 || deleteCount > 0)
                    {
                        MessageBox.Show($"실험 결과 저장이 완료되었습니다!\n(수정: {updateCount}건, 추가: {insertCount}건, 삭제: {deleteCount}건)", "저장 완료", MessageBoxButton.OK, MessageBoxImage.Information);
                        _dtSource.AcceptChanges(); // DB 저장 완료 후 재조회 시 미저장 경고 방지
                        ActionSearch();
                    }
                    else
                    {
                        MessageBox.Show("변경된 데이터가 없습니다.", "알림", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"데이터 저장 중 오류가 발생했습니다:\n{ex.Message}", "저장 오류", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            };

            // 선택삭제 마우스 이벤트 결합
            btnDelete.Click += (s, e) =>
            {
                if (_dataGrid.SelectedItems.Count == 0)
                {
                    MessageBox.Show("삭제할 결과 행을 선택해 주세요.", "알림", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (MessageBox.Show("선택한 행들을 화면에서 제거하시겠습니까?\n(최종 DB 반영은 '저장' 버튼을 누르셔야 처리됩니다.)", "삭제 확인", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    System.Collections.ArrayList selectedList = new System.Collections.ArrayList(_dataGrid.SelectedItems);
                    foreach (var item in selectedList)
                    {
                        if (item is DataRowView rowView)
                        {
                            rowView.Row.Delete();
                        }
                    }
                }
            };

            // 엑셀 화면 직출력 기능
            btnExport.Click += (s, e) =>
            {
                if (_dtSource == null || _dtSource.Rows.Count == 0)
                {
                    MessageBox.Show("출력할 데이터가 없습니다.", "알림", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                Excel.Application excelApp = null;
                Excel.Workbook wb = null;
                Excel.Worksheet ws = null;

                try
                {
                    excelApp = new Excel.Application();
                    excelApp.Visible = false;
                    excelApp.DisplayAlerts = false;

                    wb = excelApp.Workbooks.Add();
                    ws = (Excel.Worksheet)wb.Sheets[1];
                    ws.Name = "TestResult_View";

                    int colCount = _dtSource.Columns.Count;
                    for (int c = 0; c < colCount; c++)
                    {
                        ((Excel.Range)ws.Cells[1, c + 1]).Value = _dtSource.Columns[c].ColumnName;
                    }

                    int rowCount = _dtSource.Rows.Count;
                    int excelRowIdx = 2;

                    for (int r = 0; r < rowCount; r++)
                    {
                        DataRow row = _dtSource.Rows[r];
                        if (row.RowState == DataRowState.Deleted) continue;

                        for (int c = 0; c < colCount; c++)
                        {
                            ((Excel.Range)ws.Cells[excelRowIdx, c + 1]).Value = row[c]?.ToString() ?? "";
                        }
                        excelRowIdx++;
                    }

                    excelApp.Visible = true;
                    excelApp.DisplayAlerts = true;

                    wb = null;
                    excelApp = null;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"엑셀을 화면에 띄우는 중 오류가 발생했습니다:\n{ex.Message}", "오류", MessageBoxButton.OK, MessageBoxImage.Error);
                    if (wb != null) { wb.Dispose(); wb = null; }
                    if (excelApp != null) { excelApp.Quit(); excelApp.Dispose(); excelApp = null; }
                }
            };

            ActionSearch();

            btnSearch.Click += (s, e) => ActionSearch();
            btnAll.Click += (s, e) =>
            {
                // 기존 검색 조건을 보존할 수 있도록 확인 후에만 초기화
                if (!confirmDiscard()) return;
                txtSearch1.Clear();
                txtSearch2.Clear();
                skipDiscardOnce = true;
                ActionSearch();
            };
            btnSave.Click += (s, e) => ActionSave();
            txtSearch1.KeyDown += (s, e) => { if (e.Key == System.Windows.Input.Key.Enter) ActionSearch(); };
            txtSearch2.KeyDown += (s, e) => { if (e.Key == System.Windows.Input.Key.Enter) ActionSearch(); };

            return mainPanel;
        }

        // 🎯 [핵심 기능] 시작 열(Column) 인덱스 추적 및 메일 HTML/일반 TSV 복사-붙여넣기 완벽 대응
        private void DataGrid_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.V && (System.Windows.Input.Keyboard.Modifiers & System.Windows.Input.ModifierKeys.Control) == System.Windows.Input.ModifierKeys.Control)
            {
                e.Handled = true; // WPF 순정 붙여넣기 차단

                List<List<string>> parsedTable = null;

                // 1. 아웃룩/웹메일 HTML 표 우선 파싱
                if (Clipboard.ContainsData(DataFormats.Html))
                {
                    string htmlText = Clipboard.GetData(DataFormats.Html) as string;
                    if (!string.IsNullOrEmpty(htmlText))
                    {
                        parsedTable = ParseHtmlTable(htmlText);
                    }
                }

                // 2. HTML 실패 시 일반 텍스트(TSV) 파싱
                if (parsedTable == null || parsedTable.Count == 0)
                {
                    string clipboardText = Clipboard.GetText();
                    if (string.IsNullOrWhiteSpace(clipboardText)) return;
                    parsedTable = ParseTsvWithQuotes(clipboardText);
                }

                if (parsedTable == null || parsedTable.Count == 0) return;

                // 3. 현재 선택된 행(Row) 및 열(Column) 시작 위치 추적
                int startRowIndex = _dataGrid.SelectedIndex;
                if (startRowIndex < 0 && _dataGrid.CurrentItem != null)
                {
                    startRowIndex = _dataGrid.Items.IndexOf(_dataGrid.CurrentItem);
                }
                if (startRowIndex < 0) startRowIndex = _dtSource.Rows.Count;

                int startColumnIndex = 0;
                if (_dataGrid.CurrentCell != null && _dataGrid.CurrentCell.Column != null)
                {
                    startColumnIndex = _dataGrid.CurrentCell.Column.DisplayIndex;
                }

                // 4. 추적된 셀 위치부터 데이터 매핑
                for (int i = 0; i < parsedTable.Count; i++)
                {
                    List<string> rowCells = parsedTable[i];
                    int targetRowIndex = startRowIndex + i;

                    DataRow targetRow = null;

                    // Target 행 찾기 또는 새 행 생성
                    if (targetRowIndex < _dtSource.Rows.Count)
                    {
                        targetRow = _dtSource.Rows[targetRowIndex];
                        if (targetRow.RowState == DataRowState.Deleted) continue;
                    }
                    else
                    {
                        targetRow = _dtSource.NewRow();
                        _dtSource.Rows.Add(targetRow);
                    }

                    // 5. 선택한 열 위치부터 순서대로 매핑하여 붙여넣기
                    for (int j = 0; j < rowCells.Count; j++)
                    {
                        int targetColumnIndex = startColumnIndex + j;

                        if (targetColumnIndex < _dtSource.Columns.Count)
                        {
                            string colName = _dtSource.Columns[targetColumnIndex].ColumnName;
                            string cellVal = rowCells[j].Replace(" ", "").Trim();
                            targetRow[colName] = cellVal;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 🎯 메일/웹 HTML 표 구조(tr, td)를 직접 추출하는 파서
        /// </summary>
        private List<List<string>> ParseHtmlTable(string html)
        {
            var table = new List<List<string>>();

            try
            {
                var trMatches = System.Text.RegularExpressions.Regex.Matches(
                    html, @"<tr[^>]*>(.*?)</tr>", System.Text.RegularExpressions.RegexOptions.Singleline | System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                foreach (System.Text.RegularExpressions.Match trMatch in trMatches)
                {
                    var row = new List<string>();
                    var tdMatches = System.Text.RegularExpressions.Regex.Matches(
                        trMatch.Groups[1].Value, @"<t[dh][^>]*>(.*?)</t[dh]>", System.Text.RegularExpressions.RegexOptions.Singleline | System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                    foreach (System.Text.RegularExpressions.Match tdMatch in tdMatches)
                    {
                        string cellHtml = tdMatch.Groups[1].Value;
                        string cellText = System.Text.RegularExpressions.Regex.Replace(cellHtml, @"<[^>]+>", "").Trim();
                        cellText = System.Net.WebUtility.HtmlDecode(cellText);
                        cellText = System.Text.RegularExpressions.Regex.Replace(cellText, @"\s+", " ").Trim();
                        row.Add(cellText);
                    }

                    if (row.Count > 0 && row.Exists(s => !string.IsNullOrEmpty(s)))
                    {
                        table.Add(row);
                    }
                }
            }
            catch { }

            return table;
        }

        /// <summary>
        /// 🎯 일반 TSV(텍스트) 파서 (쌍따옴표 내 줄바꿈 보존)
        /// </summary>
        private List<List<string>> ParseTsvWithQuotes(string text)
        {
            var result = new List<List<string>>();
            var currentRow = new List<string>();
            var currentCell = new System.Text.StringBuilder();
            bool inQuotes = false;

            string normalized = text.Replace("\r\n", "\n").Replace("\r", "\n");

            for (int i = 0; i < normalized.Length; i++)
            {
                char c = normalized[i];

                if (c == '"')
                {
                    if (inQuotes && i + 1 < normalized.Length && normalized[i + 1] == '"')
                    {
                        currentCell.Append('"');
                        i++;
                    }
                    else
                    {
                        inQuotes = !inQuotes;
                    }
                }
                else if (c == '\t' && !inQuotes)
                {
                    currentRow.Add(currentCell.ToString().Trim());
                    currentCell.Clear();
                }
                else if (c == '\n' && !inQuotes)
                {
                    currentRow.Add(currentCell.ToString().Trim());
                    currentCell.Clear();

                    if (currentRow.Exists(s => !string.IsNullOrWhiteSpace(s)))
                    {
                        result.Add(currentRow);
                    }
                    currentRow = new List<string>();
                }
                else
                {
                    currentCell.Append(c);
                }
            }

            if (currentCell.Length > 0 || currentRow.Count > 0)
            {
                currentRow.Add(currentCell.ToString().Trim());
                if (currentRow.Exists(s => !string.IsNullOrWhiteSpace(s)))
                {
                    result.Add(currentRow);
                }
            }

            return result;
        }
    }
}